IBISserial COM1 l026
IBISserial COM1 lE01
IBISserial COM1 "zA4WERKSTATTFAHRT                  WERKSTATTFAHRT                  "
