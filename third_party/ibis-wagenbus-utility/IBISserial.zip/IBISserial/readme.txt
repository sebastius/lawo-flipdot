IBISserial verschickt IBIS-Datens�tze �ber die serielle Schnittstelle.

Beispiel: IBISserial COM1 l026

Telegrammabschlu� <CR> und Parity <P> erzeugt das Programm dabei automatisch.
Der korrekte Syntax der IBIS-Datens�tze ist zu beachten.

Die Hexwerte 0x01 - 0x09 k�nnen dem Programm mittels $01-$09 im Text
�bermittelt werden, $LF erzeugt ein Linefeed, \n

Das Programm ben�tigt das .NET-Framework Version 2.0

Freeware, (c) Stephan Sch�tt, cbxpm@yahoo.de
