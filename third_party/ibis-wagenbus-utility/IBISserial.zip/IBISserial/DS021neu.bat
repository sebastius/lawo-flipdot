IBISserial COM1 q026E
IBISserial COM1 qE00
IBISserial COM1 "aA12Werkstattfahrt$LF$LF        $LF.CMN0N0"
IBISserial COM1 "aA22Werkstattfahrt$LF$LF        $LF.CMN0N0"
