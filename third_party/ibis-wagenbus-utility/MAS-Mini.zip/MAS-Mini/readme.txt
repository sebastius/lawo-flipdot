MAS-Mini ist eine Windows-Software zum Erzeugen einer einfachen Datenversorgung
f�r die MAS3 (IBIS-Master) von HPW. Das Programm erlaubt das Importieren und
Editieren von bis zu 1000 Zieltexten (999 Texte + Leerfeld).

Das Programm erzeugt daraus eine Bin�rdatei, welche mit Hilfe einer Image-
software auf die ger�teinterne PCMCIA-Speicherkarte �bertragen werden kann.

Eine bereits vorhandene Datenversorgung (Flash) bleibt erhalten und verbleibt
inaktiv im Hintergrund. Die Software ver�ndert keine Einstellungen des MAS3.

Vorraussetzung f�r den Einsatz der Software ist ein MAS3 mit PCMCIA-Speicherkarte,
welches au�erdem eine Datenversorgung vom Typ 'IFISET' verwenden kann.

Das Programm ben�tigt das .NET-Framework Version 3.5.

(c) 2012 Stephan Sch�tt, cbxpm@yahoo.de, alle Rechte vorbehalten. 

Ich hafte nicht f�r Sch�den die durch den Einsatz dieser Software entstehen.
