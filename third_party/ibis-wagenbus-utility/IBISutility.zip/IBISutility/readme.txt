﻿IBIS Wagenbus-Utility
=====================

Das IBIS Wagenbus-Utility ist eine Windows-Software zum Erzeugen und Versenden von
IBIS-Datensätzen (auch Telegramme genannt) über die serielle Schnittstelle am PC.

Das Programm ist Freeware.

Die Software übernimmt im Wesentlichen Grundfunktionen eines IBIS-Masters,
(IBIS-Steuergerät), zum Ansteuern von IBIS-Geräten (Slaves) ist jedoch ein
Pegelwandler erforderlich, welcher die Signale RS232 <-> IBIS wandelt.

Das Programm kann die wichtigsten IBIS-Datensätze erzeugen, etwa Liniennummer,
Sonderzeichen und verschiedene Zieltexte sowie Texte für Haltestellenanzeigen.

Folgende Datensätze werden unterstützt:

DS001		Liniennummer
DS001_neu	Liniennummer
DS001a 		Sonderzeichen
DS001a_neu	Sonderzeichen
DS001c 		Linienbandposition

DS003		Zielnummer
DS003a		Zieltext für Außenanzeige
DS003aMAS	Zieltexte (lang) für Außenanzeige
DS003c		Haltestellenvoranzeige
DS003d		Routennummer 3 Ziffern
DS003e		Zielbandposition

DS004		Entwertermerkmale
DS004a		Entwertermerkmale erweitert
DS004b		Entwerter Haltestellennummer
DS004c		Entwerter Haltestellentext
DS005		Uhrzeit
DS006		Datum
DS009		Haltestellenvoranzeige
DS010a		Haltestellennummer an Perlschnur
DS010b      Streckenverlaufsanzeige (Perlschnur), EXPERIMENTELL

DS021		Zieltext für Außenanzeige (mit ID)
DS021		Zieltext für Anzeigen mit Taktung
DS021_neu	Zieltext für Außenanzeige (erweitert)
DS021a      Texte für Streckenverlaufsanzeige, EXPERIMENTELL

DS030		Haltestellenansagegerät Status
DS301		Haltestellenansagegerät Version
DS036		Haltestellenansagegerät nächste Haltestelle

DS191		Kalenderdatum

Zieltexte und Texte für Haltestellenanzeigen lassen sich über einen Editor erstellen,
und bearbeiten. Die Texte können über ID's abgerufen, und auf die Anzeigen geschickt
werden. Es können auch zufällig Texte ausgewählt werden.

Die Datensätze lassen sich manuell versenden, oder über einen Timer in bestimmten
Abständen generieren. Hierbei kann der zeitliche Abstand eingestellt werden.

Für spezielle Datensätze sind Eingabefelder vorhanden.

Das Programm benötigt das .NET-Framework Version 3.5 (Runtime), und läuft unter
Windows XP, Windows Vista und Windows 7. Die Software ist kostenlos (Freeware).

Die Software muß nicht installiert werden. Es genügt, die .exe Datei im Programm-
verzeichnis zu starten. Alle dazugehörigen Daten liegen ebenfalls im Ordner.

Bugreports und Verbesserungsvorschläge an cbxpm@yahoo.de

(c) 2010-2013 Stephan Schütt, alle Rechte vorbehalten. 

Ich hafte nicht für Schäden die durch den Einsatz dieser Software entstehen.
